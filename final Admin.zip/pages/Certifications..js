import Layout from "@/components/Layout";





export default function Certifications (){
    return(
        <Layout>
            <h1>Certifications</h1>
        </Layout>
    )
}