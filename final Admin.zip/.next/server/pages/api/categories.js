"use strict";
(() => {
var exports = {};
exports.id = 957;
exports.ids = [957,748];
exports.modules = {

/***/ 8432:
/***/ ((module) => {

module.exports = require("bcryptjs");

/***/ }),

/***/ 8013:
/***/ ((module) => {

module.exports = require("mongodb");

/***/ }),

/***/ 1185:
/***/ ((module) => {

module.exports = require("mongoose");

/***/ }),

/***/ 3227:
/***/ ((module) => {

module.exports = require("next-auth");

/***/ }),

/***/ 7449:
/***/ ((module) => {

module.exports = require("next-auth/providers/credentials");

/***/ }),

/***/ 3598:
/***/ ((module) => {

module.exports = require("next-auth/providers/google");

/***/ }),

/***/ 7349:
/***/ ((module) => {

module.exports = import("@auth/mongodb-adapter");;

/***/ }),

/***/ 3137:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "W": () => (/* binding */ Category)
/* harmony export */ });
const { Schema , models , model , default: mongoose  } = __webpack_require__(1185);
const CategorySchema = new Schema({
    name: {
        type: String,
        required: true
    },
    parent: {
        type: mongoose.Types.ObjectId,
        ref: "Category"
    },
    properties: [
        {
            type: Object
        }
    ] //used those properties as a array
});
const Category = models?.Category || model("Category", CategorySchema);


/***/ }),

/***/ 5946:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "I": () => (/* binding */ mongooseConnect)
/* harmony export */ });
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1185);
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(mongoose__WEBPACK_IMPORTED_MODULE_0__);

function mongooseConnect() {
    if ((mongoose__WEBPACK_IMPORTED_MODULE_0___default().connection.readyState) === 1) {
        return mongoose__WEBPACK_IMPORTED_MODULE_0___default().connection.asPromise();
    } else {
        const uri = process.env.MONGODB_URI;
        return mongoose__WEBPACK_IMPORTED_MODULE_0___default().connect(uri);
    }
}


/***/ }),

/***/ 1412:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ handle)
/* harmony export */ });
/* harmony import */ var _lib_models_Categories__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3137);
/* harmony import */ var _lib_mongoose__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5946);
/* harmony import */ var _auth_nextauth___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6164);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_auth_nextauth___WEBPACK_IMPORTED_MODULE_2__]);
_auth_nextauth___WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



async function handle(req, res) {
    const { method  } = req;
    await (0,_lib_mongoose__WEBPACK_IMPORTED_MODULE_1__/* .mongooseConnect */ .I)();
    // await isAdminRequest(req,res);
    if (method === "GET") {
        res.json(await _lib_models_Categories__WEBPACK_IMPORTED_MODULE_0__/* .Category.find */ .W.find().populate("parent"));
    }
    if (method === "POST") {
        const { name , parentCategory , properties  } = req.body;
        const categoryDoc = await _lib_models_Categories__WEBPACK_IMPORTED_MODULE_0__/* .Category.create */ .W.create({
            name,
            parent: parentCategory || undefined,
            properties
        });
        res.json(categoryDoc);
    }
    if (method === "PUT") {
        const { name , parentCategory , properties , _id  } = req.body;
        const categoryDoc = await _lib_models_Categories__WEBPACK_IMPORTED_MODULE_0__/* .Category.updateOne */ .W.updateOne({
            _id
        }, {
            name,
            parent: parentCategory || undefined,
            properties
        });
        res.json(categoryDoc);
    }
    if (method === "DELETE") {
        const { _id  } = req.query;
        await _lib_models_Categories__WEBPACK_IMPORTED_MODULE_0__/* .Category.deleteOne */ .W.deleteOne({
            _id
        });
        res.json("ok");
    }
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [164], () => (__webpack_exec__(1412)));
module.exports = __webpack_exports__;

})();