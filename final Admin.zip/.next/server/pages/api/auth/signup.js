"use strict";
(() => {
var exports = {};
exports.id = 11;
exports.ids = [11];
exports.modules = {

/***/ 8432:
/***/ ((module) => {

module.exports = require("bcryptjs");

/***/ }),

/***/ 1185:
/***/ ((module) => {

module.exports = require("mongoose");

/***/ }),

/***/ 2069:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1185);
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(mongoose__WEBPACK_IMPORTED_MODULE_0__);

const connectMongo = async ()=>{
    try {
        const { connection  } = await mongoose__WEBPACK_IMPORTED_MODULE_0___default().connect(process.env.MONGODB_URI);
        if (connection.readyState == 1) {
            return Promise.resolve(true);
        }
    } catch (error) {
        return Promise.reject(error);
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (connectMongo);


/***/ }),

/***/ 8213:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const { Schema , models , model  } = __webpack_require__(1185);
const userSchema = new Schema({
    username: String,
    email: String,
    password: String
});
const Users = models.user || model("user", userSchema);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Users);


/***/ }),

/***/ 9784:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ handler)
/* harmony export */ });
/* harmony import */ var _database_conn__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2069);
/* harmony import */ var _models_Schema__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8213);
/* harmony import */ var bcryptjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8432);
/* harmony import */ var bcryptjs__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(bcryptjs__WEBPACK_IMPORTED_MODULE_2__);



async function handler(req, res) {
    (0,_database_conn__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z)().catch((error)=>res.json({
            error: "Connection Failed...!"
        }));
    // Only POST
    if (req.method === "POST") {
        if (!req.body) return res.status(404).json({
            error: "Don't have form Data...!"
        });
        const { username , email , password  } = req.body;
        // Check duplicate users
        const checkexisting = await _models_Schema__WEBPACK_IMPORTED_MODULE_1__/* ["default"].findOne */ .Z.findOne({
            email
        });
        if (checkexisting) return res.status(409).json({
            message: "User Already Exist!!!"
        });
        try {
            // Hash Password and create user
            const hashedPassword = await (0,bcryptjs__WEBPACK_IMPORTED_MODULE_2__.hash)(password, 12);
            const user = await _models_Schema__WEBPACK_IMPORTED_MODULE_1__/* ["default"].create */ .Z.create({
                username,
                email,
                password: hashedPassword
            });
            res.status(201).json({
                status: true,
                user
            });
        } catch (error) {
            res.status(500).json({
                error: "Failed to create user"
            });
        }
    } else {
        res.status(500).json({
            message: "HTTP method not valid only post accepted!!"
        });
    }
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(9784));
module.exports = __webpack_exports__;

})();